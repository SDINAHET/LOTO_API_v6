package com.fdjloto.api.controller.admin;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminLogsController {

    // ✅ Ajuste si besoin (tu as indiqué LOTO_API_v6/logs/application.log)
    private static final Path LOG_FILE = Paths.get("logs", "application.log");

    @GetMapping(value = "/logs", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> tailLogs(@RequestParam(defaultValue = "400") int lines) throws IOException {
        if (lines < 1) lines = 1;
        if (lines > 2000) lines = 2000;

        if (!Files.exists(LOG_FILE)) {
            return ResponseEntity.ok("[INFO] Fichier introuvable : " + LOG_FILE.toAbsolutePath());
        }

        List<String> all = Files.readAllLines(LOG_FILE, StandardCharsets.UTF_8);
        int from = Math.max(0, all.size() - lines);
        String out = String.join("\n", all.subList(from, all.size()));
        return ResponseEntity.ok(out.isBlank() ? "(Aucun log pour le moment)" : out);
    }
}
