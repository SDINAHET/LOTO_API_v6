package com.fdjloto.api.controller.admin;

import com.fdjloto.api.model.User;
import com.fdjloto.api.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/admin/users")
public class AdminUserController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminUserController(UserRepository userRepository,
                               PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // LIST
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    // GET ONE
    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable String id) {
        Optional<User> userOpt = userRepository.findById(id);
        return userOpt.<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body("User not found"));
    }

    // CREATE
    @PostMapping
    public ResponseEntity<?> createUser(@RequestBody User payload) {
        if (payload.getEmail() == null || payload.getEmail().isBlank()) {
            return ResponseEntity.badRequest().body("Email is required");
        }
        if (payload.getPassword() == null || payload.getPassword().isBlank()) {
            return ResponseEntity.badRequest().body("Password is required");
        }

        // encode password
        payload.setPassword(passwordEncoder.encode(payload.getPassword()));

        // default flags
        if (payload.getRole() == null || payload.getRole().isBlank()) {
            payload.setRole("USER");
        }
        payload.setCreatedAt(LocalDateTime.now());
        payload.setUpdatedAt(LocalDateTime.now());

        User saved = userRepository.save(payload);
        return ResponseEntity.ok(saved);
    }

    // UPDATE
    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable String id, @RequestBody User payload) {
        Optional<User> userOpt = userRepository.findById(id);
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(404).body("User not found");
        }

        User existing = userOpt.get();

        if (payload.getEmail() != null && !payload.getEmail().isBlank()) existing.setEmail(payload.getEmail());
        if (payload.getFirstName() != null) existing.setFirstName(payload.getFirstName());
        if (payload.getLastName() != null) existing.setLastName(payload.getLastName());
        if (payload.getRole() != null && !payload.getRole().isBlank()) existing.setRole(payload.getRole());

        // Si un mot de passe est fourni, on le re-encode
        if (payload.getPassword() != null && !payload.getPassword().isBlank()) {
            existing.setPassword(passwordEncoder.encode(payload.getPassword()));
        }

        existing.setUpdatedAt(LocalDateTime.now());
        User saved = userRepository.save(existing);

        return ResponseEntity.ok(saved);
    }

    /**
     * DELETE = "soft delete" simple SANS migration :
     * - on anonymise l'utilisateur comme dans ta méthode deleteOwnAccount()
     * - pas besoin de deletedAt / anonymized en DB
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> softDeleteUser(@PathVariable String id) {
        Optional<User> userOpt = userRepository.findById(id);
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(404).body("User not found");
        }

        User user = userOpt.get();

        // anonymisation simple
        user.setFirstName("DELETED");
        user.setLastName("USER");
        user.setEmail("deleted_" + UUID.randomUUID() + "@deleted.local");
        user.setPassword("DELETED"); // tu peux aussi encoder "DELETED" si tu veux
        user.setRole("USER");
        user.setUpdatedAt(LocalDateTime.now());

        userRepository.save(user);

        return ResponseEntity.ok("User anonymized (soft delete) successfully");
    }
}
