package com.fdjloto.api.controller.admin;

import com.fdjloto.api.model.Ticket;
import com.fdjloto.api.model.TicketGain;
import com.fdjloto.api.model.User;
import com.fdjloto.api.repository.TicketGainRepository;
import com.fdjloto.api.repository.TicketRepository;
import com.fdjloto.api.repository.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@CrossOrigin(
        origins = "http://127.0.0.1:5500",
        allowCredentials = "true",
        allowedHeaders = "*",
        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE}
)
@RestController
@RequestMapping("/api/admin/tickets")
@Tag(name = "Admin - Tickets", description = "Admin CRUD for tickets")
@PreAuthorize("hasRole('ADMIN')")
public class AdminTicketController {

    private final TicketRepository ticketRepository;
    private final UserRepository userRepository;

    public AdminTicketController(TicketRepository ticketRepository, UserRepository userRepository) {
        this.ticketRepository = ticketRepository;
        this.userRepository = userRepository;
    }

    // DTO (simple) for dashboard admin
    public static class AdminTicketRequest {
        @NotBlank
        private String userId;

        @NotNull
        private Integer luckyNumber;

        @NotNull
        private Integer[] numbers; // expects 5 numbers

        // getters/setters
        public String getUserId() { return userId; }
        public void setUserId(String userId) { this.userId = userId; }

        public Integer getLuckyNumber() { return luckyNumber; }
        public void setLuckyNumber(Integer luckyNumber) { this.luckyNumber = luckyNumber; }

        public Integer[] getNumbers() { return numbers; }
        public void setNumbers(Integer[] numbers) { this.numbers = numbers; }
    }

    @Operation(summary = "List all tickets (admin)")
    @GetMapping
    public ResponseEntity<List<Ticket>> list() {
        return ResponseEntity.ok(ticketRepository.findAll());
    }

    @Operation(summary = "Get ticket by id (admin)")
    @GetMapping("/{id}")
    public ResponseEntity<Ticket> get(@PathVariable UUID id) {
        return ticketRepository.findById(id.toString())
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Create a ticket for a user (admin)")
    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody AdminTicketRequest req) {

        Optional<User> userOpt = userRepository.findById(req.getUserId());
        if (userOpt.isEmpty()) return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");

        if (req.getNumbers() == null || req.getNumbers().length != 5) {
            return ResponseEntity.badRequest().body("numbers must contain exactly 5 values");
        }

        Ticket t = new Ticket();
        t.setId(UUID.randomUUID().toString());
        t.setUser(userOpt.get());

        // Ticket model in your project uses int fields: number1..number5 + chanceNumber
        t.setNumber1(req.getNumbers()[0]);
        t.setNumber2(req.getNumbers()[1]);
        t.setNumber3(req.getNumbers()[2]);
        t.setNumber4(req.getNumbers()[3]);
        t.setNumber5(req.getNumbers()[4]);
        t.setChanceNumber(req.getLuckyNumber());

        Ticket saved = ticketRepository.save(t);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @Operation(summary = "Update a ticket (admin)")
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable UUID id, @Valid @RequestBody AdminTicketRequest req) {

        Optional<Ticket> ticketOpt = ticketRepository.findById(id.toString());
        if (ticketOpt.isEmpty()) return ResponseEntity.notFound().build();

        Ticket existing = ticketOpt.get();

        // Optional: change owner
        if (req.getUserId() != null && !req.getUserId().isBlank()) {
            Optional<User> userOpt = userRepository.findById(req.getUserId());
            if (userOpt.isEmpty()) return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            existing.setUser(userOpt.get());
        }

        if (req.getNumbers() == null || req.getNumbers().length != 5) {
            return ResponseEntity.badRequest().body("numbers must contain exactly 5 values");
        }

        existing.setNumber1(req.getNumbers()[0]);
        existing.setNumber2(req.getNumbers()[1]);
        existing.setNumber3(req.getNumbers()[2]);
        existing.setNumber4(req.getNumbers()[3]);
        existing.setNumber5(req.getNumbers()[4]);
        existing.setChanceNumber(req.getLuckyNumber());

        Ticket saved = ticketRepository.save(existing);
        return ResponseEntity.ok(saved);
    }

    @Operation(summary = "Delete a ticket (admin)")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        Optional<Ticket> ticketOpt = ticketRepository.findById(id.toString());
        if (ticketOpt.isEmpty()) return ResponseEntity.notFound().build();

        ticketRepository.delete(ticketOpt.get());
        return ResponseEntity.noContent().build();
    }
}


/**
 * READ-ONLY: /api/admin/ticket-gains
 * (separate controller in same file, package-private, OK in Java)
 */
@CrossOrigin(
        origins = "http://127.0.0.1:5500",
        allowCredentials = "true",
        allowedHeaders = "*",
        methods = {RequestMethod.GET}
)
@RestController
@RequestMapping("/api/admin/ticket-gains")
@Tag(name = "Admin - TicketGains", description = "Admin read-only for ticket gains")
@PreAuthorize("hasRole('ADMIN')")
class AdminTicketGainController {

    private final TicketGainRepository ticketGainRepository;

    public AdminTicketGainController(TicketGainRepository ticketGainRepository) {
        this.ticketGainRepository = ticketGainRepository;
    }

    @Operation(summary = "List all ticket gains (admin, read-only)")
    @GetMapping
    public ResponseEntity<List<TicketGain>> list(@RequestParam(name = "ticketId", required = false) String ticketId) {
        if (ticketId != null && !ticketId.isBlank()) {
            return ResponseEntity.ok(ticketGainRepository.findByTicketId(ticketId));
        }
        return ResponseEntity.ok(ticketGainRepository.findAll());
    }

    @Operation(summary = "Get ticket gain by id (admin, read-only)")
    @GetMapping("/{id}")
    public ResponseEntity<TicketGain> get(@PathVariable String id) {
        return ticketGainRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
