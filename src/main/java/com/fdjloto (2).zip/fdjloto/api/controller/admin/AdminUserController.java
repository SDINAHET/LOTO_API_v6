package com.fdjloto.api.controller.admin;

import com.fdjloto.api.model.User;
import com.fdjloto.api.repository.TicketRepository;
import com.fdjloto.api.repository.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@CrossOrigin(
        origins = "http://127.0.0.1:5500",
        allowCredentials = "true",
        allowedHeaders = "*",
        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE}
)
@RestController
@RequestMapping("/api/admin/users")
@Tag(name = "Admin - Users", description = "Admin CRUD for users")
@PreAuthorize("hasRole('ADMIN')")
public class AdminUserController {

    private final UserRepository userRepository;
    private final TicketRepository ticketRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminUserController(UserRepository userRepository,
                               TicketRepository ticketRepository,
                               PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.ticketRepository = ticketRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Operation(summary = "List all users (admin)")
    @GetMapping
    public ResponseEntity<List<User>> list() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    @Operation(summary = "Get one user by id (admin)")
    @GetMapping("/{id}")
    public ResponseEntity<User> get(@PathVariable UUID id) {
        return userRepository.findById(id.toString())
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Create a user (admin)")
    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody User user) {

        // Always generate an id if missing
        if (user.getId() == null || user.getId().isBlank()) {
            user.setId(UUID.randomUUID().toString());
        }

        // Email must be unique
        if (user.getEmail() != null && userRepository.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Email already exists");
        }

        // Password must be encoded if provided
        if (user.getPassword() != null && !user.getPassword().isBlank()) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        } else {
            return ResponseEntity.badRequest().body("Password is required");
        }

        // admin flag is allowed (true/false)
        User saved = userRepository.save(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @Operation(summary = "Update a user (admin)")
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable UUID id, @Valid @RequestBody User incoming) {

        Optional<User> opt = userRepository.findById(id.toString());
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        User existing = opt.get();

        // Update allowed fields
        if (incoming.getFirstName() != null) existing.setFirstName(incoming.getFirstName().trim());
        if (incoming.getLastName() != null) existing.setLastName(incoming.getLastName().trim());

        // Allow admin to change email ONLY if unique
        if (incoming.getEmail() != null && !incoming.getEmail().isBlank()
                && !incoming.getEmail().equalsIgnoreCase(existing.getEmail())) {
            if (userRepository.findByEmail(incoming.getEmail()).isPresent()) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("Email already exists");
            }
            existing.setEmail(incoming.getEmail().trim());
        }

        // Allow admin flag change
        existing.setAdmin(incoming.isAdmin());

        // Optional password change (encode)
        if (incoming.getPassword() != null && !incoming.getPassword().isBlank()) {
            existing.setPassword(passwordEncoder.encode(incoming.getPassword()));
        }

        User saved = userRepository.save(existing);
        return ResponseEntity.ok(saved);
    }

    @Operation(summary = "Delete (soft) a user (admin) - anonymize immediately")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {

        Optional<User> opt = userRepository.findById(id.toString());
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        User u = opt.get();

        // Same spirit as deleteOwnAccount(): remove tickets + anonymize user
        ticketRepository.deleteByUserId(u.getId());

        String anonId = UUID.randomUUID().toString();
        u.setAdmin(false);
        u.setFirstName("Deleted");
        u.setLastName("User");
        u.setEmail("anon-" + anonId + "@deleted.local");
        u.setPassword(passwordEncoder.encode(UUID.randomUUID().toString())); // random secret

        userRepository.save(u);
        return ResponseEntity.noContent().build();
    }
}
