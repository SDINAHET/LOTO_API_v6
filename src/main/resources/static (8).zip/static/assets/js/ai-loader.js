// // ai-loader.js
// (async () => {
//   try {
//     // URL de ai.html dans le même dossier que ai-loader.js
//     const base = new URL(".", document.currentScript.src);
//     const aiUrl = new URL("ai.html", base);

//     const res = await fetch(aiUrl, { cache: "no-store" });
//     if (!res.ok) throw new Error("ai.html introuvable: " + res.status);

//     const html = await res.text();

//     const host = document.createElement("div");
//     host.id = "lt-ai-host";
//     host.innerHTML = html;
//     document.body.appendChild(host);

//     // exécute les <script> contenus dans ai.html
//     host.querySelectorAll("script").forEach((old) => {
//       const s = document.createElement("script");
//       if (old.src) s.src = old.src;
//       s.textContent = old.textContent;
//       document.body.appendChild(s);
//       old.remove();
//     });
//   } catch (e) {
//     console.warn("Chatbot non chargé :", e);
//   }
// })();

// ai-loader.js
(async () => {
  try {
    // évite double chargement
    if (document.getElementById("lt-ai-host")) return;

    const cs = document.currentScript;

    // base URL robuste : currentScript sinon dernier script
    const scriptEl = cs || document.scripts[document.scripts.length - 1];
    if (!scriptEl || !scriptEl.src) {
      throw new Error("Impossible de déterminer l'URL du script (currentScript/src).");
    }

    const base = new URL(".", scriptEl.src);
    const aiUrl = new URL("ai.html", base);

    const res = await fetch(aiUrl, { cache: "no-store" });
    if (!res.ok) throw new Error("ai.html introuvable: " + res.status);

    const html = await res.text();

    const host = document.createElement("div");
    host.id = "lt-ai-host";
    host.innerHTML = html;
    document.body.appendChild(host);

    // Rejoue les scripts en conservant les attributs
    const scripts = Array.from(host.querySelectorAll("script"));
    for (const old of scripts) {
      const s = document.createElement("script");

      // copie tous les attributs (type, defer, async, etc.)
      for (const attr of old.attributes) {
        // si src relatif, on le résout par rapport au dossier du loader
        if (attr.name === "src") {
          s.src = new URL(attr.value, base).toString();
        } else {
          s.setAttribute(attr.name, attr.value);
        }
      }

      // inline script
      if (!old.src) s.textContent = old.textContent;

      document.body.appendChild(s);
      old.remove();
    }
  } catch (e) {
    console.warn("Chatbot non chargé :", e);
  }
})();
