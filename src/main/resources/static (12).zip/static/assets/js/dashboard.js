<button class="btn-danger-soft" id="logoutBtn" type="button" title="Déconnexion">
  <svg class="btn-ico" viewBox="0 0 24 24" aria-hidden="true" style="stroke:white">
    <path d="M10 17l5-5-5-5"/>
    <path d="M15 12H3"/>
    <path d="M21 3v18"/>
  </svg>
  Déconnexion
</button>
