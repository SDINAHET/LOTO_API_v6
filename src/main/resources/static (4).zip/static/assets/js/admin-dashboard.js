// ✅ API_BASE : dashboard (5500) parle au backend (8082) en local.
// En prod, tu pourras remplacer par ton domaine (ex: https://stephanedinahet.fr)
const API_BASE =
  (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1")
    ? "http://localhost:8082"
    : window.location.origin;

// ✅ JWT en cookie => pas d'Authorization header
function getAuthHeaders() { return {}; }

// ---------- NAV ----------
const navItems = document.querySelectorAll(".nav-item");
const sections = {
  swagger: document.getElementById("section-swagger"),
  logs: document.getElementById("section-logs"),
  info: document.getElementById("section-info")
};

const pageTitle = document.getElementById("pageTitle");
const pageSubtitle = document.getElementById("pageSubtitle");

const subtitles = {
  swagger: "Documentation Swagger et tests de l’API.",
  logs: "Suivi en temps réel des logs Spring Boot.",
  info: "Debug / vérifications rapides."
};

function showSection(key) {
  Object.keys(sections).forEach(k => sections[k].classList.toggle("show", k === key));
  navItems.forEach(btn => btn.classList.toggle("active", btn.dataset.section === key));

  pageTitle.textContent = "Tableau de bord administrateur";
  pageSubtitle.textContent = subtitles[key] || "";

  if (key === "logs") refreshLogs();
}

navItems.forEach(btn => btn.addEventListener("click", () => showSection(btn.dataset.section)));

// ---------- SWAGGER ----------
const swaggerFrame = document.getElementById("swaggerFrame");
const btnOpenSwagger = document.getElementById("btnOpenSwagger");

// ⚠️ L’iframe peut être bloquée si Swagger renvoie X-Frame-Options SAMEORIGIN.
// On met quand même l’URL ; si ça bloque, tu utilises le bouton "nouvel onglet".
swaggerFrame.src = `${API_BASE}/swagger-ui/index.html`;

btnOpenSwagger.addEventListener("click", () => {
  window.open(`${API_BASE}/swagger-ui/index.html`, "_blank");
});

// ---------- LOGS ----------
const logsContainer = document.getElementById("logsContainer");
const btnRefreshLogs = document.getElementById("btnRefreshLogs");
const logLineCountSelect = document.getElementById("logLineCount");
const autoScrollLogsCheckbox = document.getElementById("autoScrollLogs");
const autoRefreshLogsCheckbox = document.getElementById("autoRefreshLogs");
const logsLastRefresh = document.getElementById("logsLastRefresh");

async function refreshLogs() {
  const lines = logLineCountSelect.value;

  try {
    const res = await fetch(`${API_BASE}/admin/logs?lines=${encodeURIComponent(lines)}`, {
      method: "GET",
      headers: { ...getAuthHeaders() },
      credentials: "include"
    });

    const text = await res.text();
    logsContainer.textContent = text || "(Aucun log pour le moment)";
    logsLastRefresh.textContent = "Dernier refresh : " + new Date().toLocaleTimeString("fr-FR");

    if (autoScrollLogsCheckbox.checked) logsContainer.scrollTop = logsContainer.scrollHeight;
  } catch (e) {
    console.error(e);
    logsContainer.textContent = "[ERREUR] Impossible de charger les logs.";
  }
}

btnRefreshLogs.addEventListener("click", refreshLogs);
logLineCountSelect.addEventListener("change", refreshLogs);

setInterval(() => {
  if (autoRefreshLogsCheckbox.checked) refreshLogs();
}, 3000);

// ---------- INFO ----------
document.getElementById("apiBase").textContent = API_BASE;

const btnPing = document.getElementById("btnPing");
const pingResult = document.getElementById("pingResult");

btnPing.addEventListener("click", async () => {
  pingResult.textContent = "…";
  try {
    const res = await fetch(`${API_BASE}/admin/ping`, { credentials: "include" });
    const t = await res.text();
    pingResult.textContent = `${res.status} - ${t}`;
  } catch (e) {
    console.error(e);
    pingResult.textContent = "Erreur réseau";
  }
});

// ---------- LOGOUT ----------
document.getElementById("btnLogout").addEventListener("click", async () => {
  try {
    await fetch(`${API_BASE}/api/auth/logout`, {
      method: "POST",
      credentials: "include"
    });
  } catch (e) {
    console.error(e);
  }
  // page login en 5500
  window.location.href = "/admin-login.html";
});

// ---------- INIT ----------
showSection("swagger");
